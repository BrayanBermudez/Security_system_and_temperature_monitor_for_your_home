/*******************************************************************************
* File Name: vHigh.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "vHigh.h"

static vHigh_BACKUP_STRUCT  vHigh_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: vHigh_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function must be called for SIO and USBIO
*  pins. It is not essential if using GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet vHigh_SUT.c usage_vHigh_Sleep_Wakeup
*******************************************************************************/
void vHigh_Sleep(void)
{
    #if defined(vHigh__PC)
        vHigh_backup.pcState = vHigh_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            vHigh_backup.usbState = vHigh_CR1_REG;
            vHigh_USB_POWER_REG |= vHigh_USBIO_ENTER_SLEEP;
            vHigh_CR1_REG &= vHigh_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(vHigh__SIO)
        vHigh_backup.sioState = vHigh_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        vHigh_SIO_REG &= (uint32)(~vHigh_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: vHigh_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep().
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to vHigh_Sleep() for an example usage.
*******************************************************************************/
void vHigh_Wakeup(void)
{
    #if defined(vHigh__PC)
        vHigh_PC = vHigh_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            vHigh_USB_POWER_REG &= vHigh_USBIO_EXIT_SLEEP_PH1;
            vHigh_CR1_REG = vHigh_backup.usbState;
            vHigh_USB_POWER_REG &= vHigh_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(vHigh__SIO)
        vHigh_SIO_REG = vHigh_backup.sioState;
    #endif
}


/* [] END OF FILE */
