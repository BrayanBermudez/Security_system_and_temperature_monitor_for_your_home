/*******************************************************************************
* File Name: vHigh.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_vHigh_ALIASES_H) /* Pins vHigh_ALIASES_H */
#define CY_PINS_vHigh_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define vHigh_0			(vHigh__0__PC)
#define vHigh_0_PS		(vHigh__0__PS)
#define vHigh_0_PC		(vHigh__0__PC)
#define vHigh_0_DR		(vHigh__0__DR)
#define vHigh_0_SHIFT	(vHigh__0__SHIFT)
#define vHigh_0_INTR	((uint16)((uint16)0x0003u << (vHigh__0__SHIFT*2u)))

#define vHigh_INTR_ALL	 ((uint16)(vHigh_0_INTR))


#endif /* End Pins vHigh_ALIASES_H */


/* [] END OF FILE */
